package template.datapack;

public class DataPack {
	/*自己定义的分支事件的ID，之后写在同一个文件中方便查阅
	 *例如：考试的事件ID:"123123；
	 */
	public String ID;

	/* 环境状态的值 */
	public String date;
	public String term;
	public int dayOrNight;
	
	/* 人物状态的值 */
	public int IQ;
	public int EQ;
	public int Health;
	
	/*step表示在某个支线中走到了第几步，可以自己定义一下协议
	 * 例如：step="1231";
	 * 在第一个判断分枝选择1
	 * 第二个判断分枝选择2
	 * 第三个判断分枝选择3
	 * 第四个判断分枝选择1
	 * */
	public String step;
	public String stepNext;//表示下一步
	
	public DataPack(String type){
		if(type.equals("demo")) {
			ID="demo";
			date="0927";
			term="大四上";
			dayOrNight=0;
		}
	}
		
}
