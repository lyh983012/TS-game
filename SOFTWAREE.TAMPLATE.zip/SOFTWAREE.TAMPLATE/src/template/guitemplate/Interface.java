package template.guitemplate;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import template.datapack.DataPack;

public class Interface extends JFrame {
	
	private Game MainGame;
	public DataPack dataPackage;
	
    public void setGame(Game MainGame){
    	this.MainGame=MainGame;
    }
	public Interface(){
			JFrame login = new JFrame("基本页面");
			login.setSize(400,200);
			login.setResizable(false);
			login.getContentPane().setLayout(new GridLayout(3,2,5,5));
			//行列元件数目，水平竖直间隔
			//pane第1行
			login.getContentPane().add(new JLabel("测试数据交互1"));
			JTextField name=new JTextField(8);
			name.setSize(80,40);
			login.getContentPane().add(name);		
			//pane第2行
			login.getContentPane().add(new JLabel("测试数据交互1"));
			JTextField password=new JTextField(8);
			password.setSize(80,40);
			login.getContentPane().add(password);
			//pane第3行 添加按钮
			JButton yes =new JButton("确认");
			yes.setSize(40,20);
			login.getContentPane().add(yes);
	        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        login.setVisible(true);
			//设置按钮动作
	        
			yes.addActionListener(new ActionListener(){
	    		@Override
	    		public void actionPerformed(ActionEvent e) {
	    			/* 		在下面进行dataPack的处理	*/
	        		/*		START OF YOUR CODE		*/
	    			dataPackage.ID=name.getText();
	    			dataPackage.term=password.getText();
	    			MainGame.dataPackage=dataPackage;
	
	        		
	        		/*		END OF YOUR CODE		*/
	    			synchronized(MainGame) {
	    				//以MainGame进程自己为保护区域，可以实现底层的唤醒 
	    				MainGame.notify();
	    			}
        		}
	    	});
			return;
	}
}
