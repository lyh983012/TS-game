package template.guitemplate;

import template.datapack.DataPack;

public class Game extends Thread{
    private Interface GUI;
	private String threadName;
	public DataPack dataPackage;
    Game(String name) {
       this.threadName = name;
    }
    public void setGUI(Interface GUI){
    	this.GUI=GUI;
    }
    public void run(){
    	while(true){
    		/* 		在下面进行分支事件的选择		*/
    		/*		START OF YOUR CODE		*/
    		
    		GUI.dataPackage=dataPackage;
    		System.out.println(dataPackage.ID);
    		System.out.println(dataPackage.term);
    		
    		/*		END OF YOUR CODE		*/
    		
    		/*对分支事件的想法
    		 *分支事件收到datapack,调用actOn，处理数据包
    		 *用step确定上一次执行到哪里，用stepnext返回下一个数据包
    		 *最后把数据包发回到绘图进程里，进行判断
    		 demo:
	    		  if (dataPackage.datOrNight==0){
	    		  		dataPackage=dayEvent.actOn(dataPackage);
	    		  	}else{
	    		  		dataPackage=nightEvent.actOn(dataPackage);
	    		  	}
	    		  int dice=ranomint();
	    		  switch(dice){
	    		  		case 1:
	    		  		dataPackage=Event1.actOn(dataPackage);
	    		  		break;
	     		  		case 2:
	    		  		dataPackage=Event2.actOn(dataPackage);
	    		  		break;
	    		  }
    		 */
    		
	    	synchronized(this){
		   		try {
					this.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		   	}
    	}
	}

}
