package template.guitemplate;

import java.awt.EventQueue;
import java.io.*;

import template.datapack.DataPack;

/*
 * template version 1.0
 * 游戏的主体
 * 	维护底层进程 以及 图形界面进程
 * 
 * */
public class TestThread {

	    public DataPack dataPackage;
		private static Game mainGame;
		private static Interface mainGUI;
	 
	   	public static void main(String args[]) {
		    mainGame = new Game( "main_game");
		    mainGame.start();
		    mainGUI = new Interface();
		    DataPack dataPackage=new DataPack("demo");
		    
		    mainGame.dataPackage=dataPackage;
		    
		    mainGame.setGUI(mainGUI);
			mainGUI.setGame(mainGame);
			mainGame.run();
	   }   
	}



