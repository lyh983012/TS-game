package template.event;
import template.datapack.DataPack;

public class EventTemplate {
	
	public DataPack nextDataPack;
	public DataPack actOn(DataPack oldDataPack) {
		/* 		在下面进行dataPack的处理	*/
		/*		START OF YOUR CODE		*/


		
		/*		END OF YOUR CODE		*/
		return nextDataPack;
	}
}
